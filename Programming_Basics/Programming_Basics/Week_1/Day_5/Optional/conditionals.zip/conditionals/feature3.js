function feature3(time){
    var evens=['ice cream','cookies','candy'];
    var random_even=Math.floor(Math.random()*evens.length);
    var even=evens[random_even]
    var odds=['hot chocolat','tea','cake'];
    var random_odd=Math.floor(Math.random()*odds.length);
    var odd=odds[random_odd]
    
    
    if(3<time<6 && time%2===0){
        console.log("i want ",even);
    }
    else{
        
        console.log("i want  ",odd);
    }
}
feature3(5)