function feature2(time){
    if(3<time<6 && time%2===0){
        console.log("i want an icecream");
    }
    else{
        
        console.log("i want a hot chocolate ");
    }
}