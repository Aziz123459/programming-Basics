

function ice_cream(day){
    var icecream=""
    if(day=="wednesday"){
        icecream="strawberry"
        console.log(icecream)
    }
    else{
        icecream="vanilla"
        console.log(icecream)
    }
}
ice_cream("monday")
